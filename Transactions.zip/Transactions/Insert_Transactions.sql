USE [SampleData]
GO

/****** Object:  StoredProcedure [dbo].[INSERT_TRANSACTIONS]    Script Date: 16/11/2016 01:06:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[INSERT_TRANSACTIONS] 
	-- Add the parameters for the stored procedure here
	@Account text,
	@Desc text,
	@CurrencyCode varchar(10),
	@Amount decimal
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO dbo.Transactions(Account,[Description],CurrencyCode,Amount)
    VALUES(@Account,@Desc,@CurrencyCode,@Amount)
END

GO


